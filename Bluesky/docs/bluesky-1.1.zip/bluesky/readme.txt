BLUE:SKY - A OPEN SOURCE TEMPLATE
----------------------------------------------------------------------
Author          : Jonas John
Official website: http://www.jonasjohn.de/lab/free-homepage-templates.htm
Last update     : May 15, 2006
Current version : 1.1
----------------------------------------------------------------------

Blue:sky is my first open source website template that I made 
for oswd.org. It does not use tables, is XHTML 1.0 Strict and CSS 
valid :-)

I also included 5 alternative layouts, a handheld version
and a print stylesheet.


Feel free to use this template for any commercial or private website!

License: Public Domain

----------------------------------------------------------------------
How to upgrade from version 1.0 to 1.1:
----------------------------------------------------------------------

Just replace the bluesky.css with the new version which is included
in this package. But be careful not to overwrite the changes you
did to the bluesky.css.


----------------------------------------------------------------------
Stock photos used in this template:
----------------------------------------------------------------------

The two small pictures used in blue:sky are from myself,
you can download big versions of the here (license free):

The light thing:
http://www.photocase.de/photodetail.asp?i=14002

The small flower:
http://www.photocase.de/photodetail.asp?i=14015

----------------------------------------------------------------------
Recent changes:
----------------------------------------------------------------------

May 15, 2006 - Version 1.1
- Fixed the problems with forms (borders are now displayed)
- I added 4 alternative layouts - see bluesky_alt_<x>.css
  files

March 6, 2006 - Version 1.0
- created the complete website and
  submitted the design to oswd.org

